import { TableData } from "./component/TableData";

function App() {
  return (
    <>
      <TableData />
    </>
  );
}

export default App;
